package com.example.madcw

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class LoginFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var btnLogin: Button
    private lateinit var btnReset: Button
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_login, container, false)

        // Initialize views
        btnLogin = view.findViewById(R.id.btnLogin)
        etEmail = view.findViewById(R.id.etEmail)
        etPassword = view.findViewById(R.id.etPassword)
        btnReset = view.findViewById(R.id.btnReset)


        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // First try Firebase Auth (for admins)
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { authTask ->
                    if (authTask.isSuccessful) {
                        // Check if this is an admin
                        checkAdminRole(auth.currentUser?.uid ?: "")
                    } else {
                        // If Firebase auth fails, check Realtime DB for teachers/students
                        checkTeacherOrStudent(email, password)
                    }
                }
        }

        btnReset.setOnClickListener {
            etEmail.text.clear()
            etPassword.text.clear()
            Toast.makeText(requireContext(), "Fields cleared", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkAdminRole(uid: String) {
        database.reference.child("admins").child(uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        loadAdminDashboard(uid)
                    } else {
                        auth.signOut()
                        Toast.makeText(
                            requireContext(),
                            "Admin credentials not found",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(
                        requireContext(),
                        "Failed to verify admin status",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun checkTeacherOrStudent(email: String, password: String) {
        // Check teachers first
        database.reference.child("lecturers")
            .orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (teacherSnapshot in snapshot.children) {
                            val teacher = teacherSnapshot.getValue(Teacher::class.java)
                            if (teacher?.password == password) {
                                loadTeacherDashboard(teacher.id)
                                return
                            }
                        }
                    }

                    // If not a teacher, check students
                    checkStudent(email, password)
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(
                        requireContext(),
                        "Failed to verify teacher status",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun checkStudent(email: String, password: String) {
        database.reference.child("Student")
            .orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (studentSnapshot in snapshot.children) {
                            val student = studentSnapshot.getValue(Student::class.java)
                            if (student?.password == password) {
                                loadStudentDashboard(student.studentId)
                                return
                            }
                        }
                    }
                    Toast.makeText(
                        requireContext(),
                        "Invalid credentials for any role",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(
                        requireContext(),
                        "Failed to verify student status",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun loadAdminDashboard(uid: String) {
        Toast.makeText(requireContext(), "User ID: $uid", Toast.LENGTH_SHORT).show()
        val fragment = AdminDashboardFragment.newInstance(uid)
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private fun loadTeacherDashboard(teacherId: String) {
        Toast.makeText(requireContext(), "Teacher ID: $teacherId", Toast.LENGTH_SHORT).show()
        val fragment = TeacherDashboardFragment.newInstance(teacherId)
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private fun loadStudentDashboard(studentId: String) {
        Toast.makeText(requireContext(), "Student ID: $studentId", Toast.LENGTH_SHORT).show()
        val fragment = StudentDashboardFragment.newInstance(studentId)


        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    data class Teacher(
        val id: String = "",
        val email: String = "",
        val password: String = "",
        val name: String = ""
    )

    data class Student(
        val studentId: String = "",
        val email: String = "",
        val password: String = "",
        val name: String = ""
    )
}