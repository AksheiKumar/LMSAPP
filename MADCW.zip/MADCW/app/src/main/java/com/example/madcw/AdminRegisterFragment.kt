package com.example.madcw

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class AdminRegisterFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_admin_register, container, false)

        // Initialize Firebase instances
        auth = Firebase.auth
        database = FirebaseDatabase.getInstance().reference

        view.findViewById<Button>(R.id.btnRegisterAdmin).setOnClickListener {
            registerAdmin(
                name = view.findViewById<EditText>(R.id.etAdminName).text.toString().trim(),
                nic = view.findViewById<EditText>(R.id.etAdminNic).text.toString().trim(),
                email = view.findViewById<EditText>(R.id.etAdminEmail).text.toString().trim(),
                password = view.findViewById<EditText>(R.id.etAdminPassword).text.toString(),
                confirmPassword = view.findViewById<EditText>(R.id.etAdminConfirmPassword).text.toString()
            )
        }

        return view
    }

    private fun registerAdmin(name: String, nic: String, email: String, password: String, confirmPassword: String) {
        if (!validateInputs(name, nic, email, password, confirmPassword)) return

        //  Create authentication account
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { authTask ->
                if (authTask.isSuccessful) {
                    //  Save additional data to Realtime Database
                    val user = auth.currentUser
                    user?.let {
                        val adminData = hashMapOf(
                            "name" to name,
                            "nic" to nic,
                            "email" to email,
                            "createdAt" to System.currentTimeMillis()
                        )

                        database.child("admins").child(user.uid).setValue(adminData)
                            .addOnSuccessListener {
                                Toast.makeText(
                                    requireContext(),
                                    "Admin registered successfully",
                                    Toast.LENGTH_SHORT
                                ).show()
                                clearForm()
                            }
                            .addOnFailureListener { e ->
                                user.delete() // Rollback auth creation if DB fails
                                showError("Failed to save admin data: ${e.message}")
                            }
                    }
                } else {
                    showError("Authentication failed: ${authTask.exception?.message}")
                }
            }
    }

    private fun validateInputs(name: String, nic: String, email: String, password: String, confirmPassword: String): Boolean {
        return when {
            name.isEmpty() -> showError("Please enter full name")
            nic.isEmpty() -> showError("Please enter NIC number")
            !isValidNic(nic) -> showError("Invalid NIC format")
            email.isEmpty() -> showError("Please enter email")
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> showError("Invalid email format")
            password.isEmpty() -> showError("Please enter password")
            password.length < 6 -> showError("Password must be at least 6 characters")
            password != confirmPassword -> showError("Passwords don't match")
            else -> true
        }
    }

    // NIC validation
    private fun isValidNic(nic: String): Boolean {
        val cleanNic = nic.trim().replace("[^0-9Vv]".toRegex(), "").uppercase()
        return when {
            cleanNic.matches("^[0-9]{9}[V]\$".toRegex()) ->
                cleanNic.substring(2, 5).toIntOrNull() in 1..866
            cleanNic.matches("^[0-9]{12}\$".toRegex()) ->
                cleanNic.substring(0, 4).toIntOrNull() in 1900..2099
            else -> false
        }
    }

    private fun clearForm() {
        view?.apply {
            findViewById<EditText>(R.id.etAdminName).text?.clear()
            findViewById<EditText>(R.id.etAdminNic).text?.clear()
            findViewById<EditText>(R.id.etAdminEmail).text?.clear()
            findViewById<EditText>(R.id.etAdminPassword).text?.clear()
            findViewById<EditText>(R.id.etAdminConfirmPassword).text?.clear()
        }
    }

    private fun showError(message: String): Boolean {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        return false
    }

    companion object {
        fun newInstance() = AdminRegisterFragment()
    }
}