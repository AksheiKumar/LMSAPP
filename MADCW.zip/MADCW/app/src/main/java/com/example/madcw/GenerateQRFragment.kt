package com.example.madcw

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

class GenerateQRFragment : Fragment() {
    private lateinit var qrImageView: ImageView
    private lateinit var studentInfoTv: TextView
    private lateinit var database: FirebaseDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_generate_q_r, container, false)

        qrImageView = view.findViewById(R.id.qrImageView)
        studentInfoTv = view.findViewById(R.id.studentInfoTv)
        database = FirebaseDatabase.getInstance()

        // Get student ID from arguments
        val studentId = arguments?.getString("studentId") ?: run {
            studentInfoTv.text = "Error: Student ID not found"
            return view
        }

        fetchStudentData(studentId)
        return view
    }

    private fun fetchStudentData(studentId: String) {
        database.getReference("Student").child(studentId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val name = snapshot.child("name").getValue(String::class.java) ?: ""
                        val courseId = snapshot.child("courseId").getValue(String::class.java) ?: ""

                        // Generate QR with all necessary data
                        val qrContent = "$studentId|$name|$courseId"
                        generateQRCode(qrContent)

                        // Display student info
                        studentInfoTv.text = """
                            Student ID: $studentId
                            Name: $name
                            Course: $courseId
                        """.trimIndent()
                    } else {
                        studentInfoTv.text = "Student data not found in database"
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    studentInfoTv.text = "Failed to load student data: ${error.message}"
                }
            })
    }

    private fun generateQRCode(content: String) {
        try {
            val bitMatrix: BitMatrix = MultiFormatWriter().encode(
                content,
                BarcodeFormat.QR_CODE,
                500,
                500
            )

            val width = bitMatrix.width
            val height = bitMatrix.height
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)

            for (x in 0 until width) {
                for (y in 0 until height) {
                    bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }

            qrImageView.setImageBitmap(bitmap)
        } catch (e: Exception) {
            studentInfoTv.text = "Failed to generate QR code: ${e.message}"
        }
    }

    companion object {
        fun newInstance(studentId: String) = GenerateQRFragment().apply {
            arguments = Bundle().apply {
                putString("studentId", studentId)
            }
        }
    }
}