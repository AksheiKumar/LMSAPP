package com.example.madcw

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.firebase.database.*

class StudentRegisterFragment : Fragment() {

    private lateinit var etRegName: EditText
    private lateinit var etRegStudentId: EditText
    private lateinit var etRegEmail: EditText
    private lateinit var etRegPhone: EditText
    private lateinit var etRegAge: EditText
    private lateinit var etRegNic: EditText
    private lateinit var rgGender: RadioGroup
    private lateinit var rbMale: RadioButton
    private lateinit var rbFemale: RadioButton
    private lateinit var spinnerCourse: Spinner
    private lateinit var btnRegister: Button

    private lateinit var database: DatabaseReference
    private lateinit var courseList: MutableList<Course>
    private var selectedCourseId: String = ""
    private var selectedGender: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_student_register, container, false)

        try {
            // Initialize views
            etRegName = view.findViewById(R.id.etRegName)
            etRegStudentId = view.findViewById(R.id.etRegStudentId)
            etRegEmail = view.findViewById(R.id.etRegEmail)
            etRegPhone = view.findViewById(R.id.etRegPhone)
            etRegAge = view.findViewById(R.id.etRegAge)
            etRegNic = view.findViewById(R.id.etRegNic)
            rgGender = view.findViewById(R.id.rgGender)
            rbMale = view.findViewById(R.id.rbMale)
            rbFemale = view.findViewById(R.id.rbFemale)
            spinnerCourse = view.findViewById(R.id.spinnerCourse)
            btnRegister = view.findViewById(R.id.btnRegister)

            // Initialize Firebase Database
            database = FirebaseDatabase.getInstance().reference

            // Set up gender radio group listener
            rgGender.setOnCheckedChangeListener { _, checkedId ->
                selectedGender = when (checkedId) {
                    R.id.rbMale -> "Male"
                    R.id.rbFemale -> "Female"
                    else -> ""
                }
            }

            // Load courses
            loadCourses()

            btnRegister.setOnClickListener {
                try {
                    registerStudent()
                } catch (e: Exception) {
                    showToast("Registration error: ${e.message}")
                    Log.e("StudentRegister", "Registration failed", e)
                }
            }

        } catch (e: Exception) {
            showToast("Initialization error: ${e.message}")
            Log.e("StudentRegister", "View initialization failed", e)
        }

        return view
    }

    private fun loadCourses() {
        try {
            courseList = mutableListOf()

            database.child("courses").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    try {
                        if (!snapshot.exists()) {
                            showToast("No courses available")
                            return
                        }

                        courseList.clear()
                        for (courseSnapshot in snapshot.children) {
                            val courseId = courseSnapshot.key ?: continue
                            val courseName = courseSnapshot.child("name").getValue(String::class.java)
                                ?: "Unnamed Course"

                            val course = Course().apply {
                                id = courseId
                                name = courseName
                            }
                            courseList.add(course)
                        }

                        // Sort courses alphabetically by name
                        courseList.sortBy { it.name }

                        // Create adapter with course names
                        val adapter = ArrayAdapter(
                            requireContext(),
                            android.R.layout.simple_spinner_item,
                            courseList.map { it.name }
                        ).apply {
                            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        }

                        spinnerCourse.adapter = adapter
                        spinnerCourse.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                selectedCourseId = courseList[position].id
                                Log.d("CourseSelection", "Selected course ID: $selectedCourseId")
                            }
                            override fun onNothingSelected(parent: AdapterView<*>?) {
                                selectedCourseId = ""
                            }
                        }

                        // Set default selection if available
                        if (courseList.isNotEmpty()) {
                            selectedCourseId = courseList[0].id
                        }

                    } catch (e: Exception) {
                        showToast("Error loading courses")
                        Log.e("StudentRegister", "Course data parsing failed", e)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    showToast("Failed to load courses")
                    Log.e("StudentRegister", "Courses load cancelled: ${error.message}")
                }
            })
        } catch (e: Exception) {
            Log.e("StudentRegister", "Course loading failed", e)
        }
    }

    private fun registerStudent() {
        val name = etRegName.text.toString().trim()
        val studentId = etRegStudentId.text.toString().trim()
        val email = etRegEmail.text.toString().trim()
        val phone = etRegPhone.text.toString().trim()
        val age = etRegAge.text.toString().trim()
        val nic = etRegNic.text.toString().trim()

        if (name.isEmpty() || studentId.isEmpty() || email.isEmpty() || phone.isEmpty() ||
            age.isEmpty() || nic.isEmpty()) {
            showToast("Please fill all fields")
            return
        }

        if (selectedGender.isEmpty()) {
            showToast("Please select gender")
            return
        }

        if (selectedCourseId.isEmpty()) {
            showToast("Please select a course")
            return
        }

        val password = generateRandomPassword()

        // Create student data
        val studentData = hashMapOf(
            "name" to name,
            "studentId" to studentId,
            "email" to email,
            "password" to password,
            "phone" to phone,
            "age" to age,
            "nic" to nic,
            "gender" to selectedGender,
            "courseId" to selectedCourseId,
            "enrolledSubjects" to hashMapOf<String, Boolean>()
        )

        // Prepare updates
        val updates = hashMapOf<String, Any>(
            "Student/$studentId" to studentData,
            "courses/$selectedCourseId/students/$studentId" to true
        )

        database.updateChildren(updates)
            .addOnSuccessListener {
                showToast("Registration successful!\nPassword: $password")
                clearFields()
            }
            .addOnFailureListener { e ->
                showToast("Registration failed: ${e.message}")
                Log.e("StudentRegister", "Database update failed", e)
            }
    }

    private fun generateRandomPassword(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return (1..8).map { chars.random() }.joinToString("")
    }

    private fun clearFields() {
        etRegName.text?.clear()
        etRegStudentId.text?.clear()
        etRegEmail.text?.clear()
        etRegPhone.text?.clear()
        etRegAge.text?.clear()
        etRegNic.text?.clear()
        rgGender.clearCheck()
        if (courseList.isNotEmpty()) {
            spinnerCourse.setSelection(0)
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
    }

    inner class Course {
        var id: String = ""
        var name: String = ""
    }
}