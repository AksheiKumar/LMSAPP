@file:Suppress("DEPRECATION")

package com.example.madcw

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.database.FirebaseDatabase
import com.google.zxing.integration.android.IntentIntegrator
import java.text.SimpleDateFormat
import java.util.*

class ScanAttendanceFragment : Fragment() {
    private lateinit var scanBtn: Button
    private lateinit var markBtn: Button
    private lateinit var studentNameTv: TextView
    private lateinit var studentIdTv: TextView
    private lateinit var courseTv: TextView
    private lateinit var statusTv: TextView

    private lateinit var database: FirebaseDatabase
    private var scannedStudentId: String? = null
    private var scannedName: String? = null
    private var scannedCourse: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_scan_attendance, container, false)

        scanBtn = view.findViewById(R.id.scanBtn)
        markBtn = view.findViewById(R.id.markBtn)
        studentNameTv = view.findViewById(R.id.studentNameTv)
        studentIdTv = view.findViewById(R.id.studentIdTv)
        courseTv = view.findViewById(R.id.courseTv)
        statusTv = view.findViewById(R.id.statusTv)

        database = FirebaseDatabase.getInstance()

        setupClickListeners()

        return view
    }

    private fun setupClickListeners() {
        scanBtn.setOnClickListener { startQRScan() }
        markBtn.setOnClickListener { markAttendance() }
    }

    private fun startQRScan() {
        IntentIntegrator.forSupportFragment(this)
            .setPrompt("Scan Student QR Code")
            .setOrientationLocked(false)
            .initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            handleScanResult(result)
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun handleScanResult(result: com.google.zxing.integration.android.IntentResult) {
        result.contents?.let { qrContent ->
            val parts = qrContent.split("|")
            if (parts.size >= 3) {
                scannedStudentId = parts[0]
                scannedName = parts[1]
                scannedCourse = parts[2]

                updateUI()
                markBtn.visibility = View.VISIBLE
                statusTv.text = "Student verified. Ready to mark attendance."
            } else {
                statusTv.text = "Invalid QR Code format"
            }
        } ?: run {
            statusTv.text = "Scan cancelled"
        }
    }

    private fun updateUI() {
        studentNameTv.text = "Name: ${scannedName}"
        studentIdTv.text = "ID: ${scannedStudentId}"
        courseTv.text = "Course: ${scannedCourse}"
    }

    private fun markAttendance() {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val attendanceData = mapOf(
            "studentId" to scannedStudentId,
            "name" to scannedName,
            "course" to scannedCourse,
            "date" to date,
            "timestamp" to System.currentTimeMillis()
        )

        database.getReference("attendance")
            .child(date)
            .child(scannedStudentId ?: "")
            .setValue(attendanceData)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Attendance marked successfully", Toast.LENGTH_SHORT).show()
                statusTv.text = "Attendance confirmed for ${scannedName}"
                markBtn.visibility = View.GONE
                clearData()
            }
            .addOnFailureListener {
                statusTv.text = "Failed to save attendance"
            }
    }

    private fun clearData() {
        scannedStudentId = null
        scannedName = null
        scannedCourse = null
    }
}