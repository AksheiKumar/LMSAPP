package com.example.madcw

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.FirebaseDatabase

class CourseRegisterFragment : Fragment() {

    private lateinit var subjectList: MutableList<String>
    private lateinit var adapter: SubjectAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val view = inflater.inflate(R.layout.fragment_course_register, container, false)

        val etCourseCode = view.findViewById<EditText>(R.id.etCourseCode)
        val spinnerType = view.findViewById<Spinner>(R.id.spinnerCourseType)
        val spinnerCategory = view.findViewById<Spinner>(R.id.spinnerCourseCategory)
        val etCourseName = view.findViewById<EditText>(R.id.etCourseName)
        val etCourseBatch = view.findViewById<EditText>(R.id.etCourseBatch)
        val etSubject = view.findViewById<EditText>(R.id.etSubject)
        val btnAddSubject = view.findViewById<Button>(R.id.btnAddSubject)
        val rvSubjects = view.findViewById<RecyclerView>(R.id.rvSubjects)
        val btnSubmit = view.findViewById<Button>(R.id.btnSubmitCourse)

        // Spinners
        val typeList = listOf("School of Computing", "School of Business", "School of Language", "School of Design", "School of Engineering")
        val categoryList = listOf("Certificate", "Diploma", "HND", "Degree")

        spinnerType.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, typeList)
        spinnerCategory.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, categoryList)

        // Subject logic
        subjectList = mutableListOf()
        adapter = SubjectAdapter(subjectList)
        rvSubjects.layoutManager = LinearLayoutManager(requireContext())
        rvSubjects.adapter = adapter

        btnAddSubject.setOnClickListener {
            val subject = etSubject.text.toString().trim()
            if (subject.isNotEmpty()) {
                subjectList.add(subject)
                adapter.notifyDataSetChanged()
                etSubject.text.clear()
            }
        }

        btnSubmit.setOnClickListener {
            val courseId = "COURSE" + System.currentTimeMillis().toString().takeLast(5)
            val data = mapOf(
                "id" to courseId,
                "code" to etCourseCode.text.toString().trim(),
                "type" to spinnerType.selectedItem.toString(),
                "category" to spinnerCategory.selectedItem.toString(),
                "name" to etCourseName.text.toString().trim(),
                "batch" to etCourseBatch.text.toString().trim(),
                "subjects" to subjectList
            )

            FirebaseDatabase.getInstance().getReference("courses")
                .child(courseId)
                .setValue(data)
                .addOnSuccessListener {
                    Toast.makeText(requireContext(), "Course Added", Toast.LENGTH_SHORT).show()
                }
        }

        return view
    }

    class SubjectAdapter(private val items: MutableList<String>) :
        RecyclerView.Adapter<SubjectAdapter.SubjectViewHolder>() {

        inner class SubjectViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvSubject: TextView = view.findViewById(android.R.id.text1)

            init {
                view.setOnClickListener {
                    val pos = adapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        items.removeAt(pos)
                        notifyItemRemoved(pos)
                    }
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubjectViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(android.R.layout.simple_list_item_1, parent, false)
            return SubjectViewHolder(view)
        }

        override fun onBindViewHolder(holder: SubjectViewHolder, position: Int) {
            holder.tvSubject.text = items[position]
        }

        override fun getItemCount() = items.size
    }
}
