package com.example.madcw

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.firebase.database.*

class EditStudentFragment : Fragment() {

    private lateinit var database: DatabaseReference
    private lateinit var coursesDatabase: DatabaseReference
    private lateinit var studentId: String
    private lateinit var courseList: MutableList<Course>
    private var selectedCourseId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            studentId = it.getString("studentId") ?: ""
        }

        database = FirebaseDatabase.getInstance().getReference("Student")
        coursesDatabase = FirebaseDatabase.getInstance().getReference("courses")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_edit_student, container, false)

        // Initialize views
        val etName = view.findViewById<EditText>(R.id.etEditName)
        val etEmail = view.findViewById<EditText>(R.id.etEditEmail)
        val etPhone = view.findViewById<EditText>(R.id.etEditPhone)
        val etNic = view.findViewById<EditText>(R.id.etEditNic)
        val etAge = view.findViewById<EditText>(R.id.etEditAge)
        val etPassword = view.findViewById<EditText>(R.id.etEditPassword)
        val rgGender = view.findViewById<RadioGroup>(R.id.rgEditGender)
        val rbMale = view.findViewById<RadioButton>(R.id.rbEditMale)
        val rbFemale = view.findViewById<RadioButton>(R.id.rbEditFemale)
        val spinnerCourse = view.findViewById<Spinner>(R.id.spinnerEditCourse)
        val btnSave = view.findViewById<Button>(R.id.btnSave)

        // Set initial values from arguments
        arguments?.let {
            etName.setText(it.getString("name"))
            etEmail.setText(it.getString("email"))
            etPhone.setText(it.getString("phone"))
            etNic.setText(it.getString("nic"))
            etAge.setText(it.getString("age"))
            etPassword.setText(it.getString("password"))
            selectedCourseId = it.getString("courseId") ?: ""

            when (it.getString("gender")) {
                "Male" -> rbMale.isChecked = true
                "Female" -> rbFemale.isChecked = true
            }
        }

        // Load courses for spinner
        loadCourses(spinnerCourse)

        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val nic = etNic.text.toString().trim()
            val age = etAge.text.toString().trim()
            val password = etPassword.text.toString().trim()

            val selectedGender = when (rgGender.checkedRadioButtonId) {
                R.id.rbEditMale -> "Male"
                R.id.rbEditFemale -> "Female"
                else -> ""
            }

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || nic.isEmpty() ||
                age.isEmpty() || password.isEmpty() || selectedGender.isEmpty() || selectedCourseId.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Get previous course ID to update references
            database.child(studentId).child("courseId").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val previousCourseId = snapshot.getValue(String::class.java) ?: ""

                    val updates = mapOf(
                        "name" to name,
                        "email" to email,
                        "phone" to phone,
                        "nic" to nic,
                        "age" to age,
                        "password" to password,
                        "gender" to selectedGender,
                        "courseId" to selectedCourseId
                    )

                    // Update student data
                    database.child(studentId).updateChildren(updates)
                        .addOnSuccessListener {
                            // Update course references if course changed
                            if (previousCourseId != selectedCourseId) {
                                if (previousCourseId.isNotEmpty()) {
                                    // Remove from old course
                                    coursesDatabase.child("$previousCourseId/students/$studentId").removeValue()
                                }
                                // Add to new course
                                coursesDatabase.child("$selectedCourseId/students/$studentId").setValue(true)
                            }

                            Toast.makeText(requireContext(), "Student updated!", Toast.LENGTH_SHORT).show()
                            parentFragmentManager.popBackStack()
                        }
                        .addOnFailureListener {
                            Toast.makeText(requireContext(), "Update failed!", Toast.LENGTH_SHORT).show()
                        }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error updating course references", Toast.LENGTH_SHORT).show()
                }
            })
        }

        return view
    }

    private fun loadCourses(spinner: Spinner) {
        courseList = mutableListOf()

        coursesDatabase.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                courseList.clear()
                for (courseSnapshot in snapshot.children) {
                    val courseId = courseSnapshot.key ?: continue
                    val courseName = courseSnapshot.child("name").getValue(String::class.java) ?: ""
                    courseList.add(Course(courseId, courseName))
                }

                // Create adapter
                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_spinner_item,
                    courseList.map { it.name }
                ).apply {
                    setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                }

                spinner.adapter = adapter

                // Set selection to current course
                if (selectedCourseId.isNotEmpty()) {
                    val position = courseList.indexOfFirst { it.id == selectedCourseId }
                    if (position >= 0) {
                        spinner.setSelection(position)
                    }
                }

                spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        selectedCourseId = courseList[position].id
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error loading courses", Toast.LENGTH_SHORT).show()
            }
        })
    }

    data class Course(val id: String, val name: String)

    companion object {
        fun newInstance(
            studentId: String,
            name: String,
            email: String,
            phone: String,
            nic: String,
            age: String,
            gender: String,
            courseId: String,
            password: String
        ) = EditStudentFragment().apply {
            arguments = Bundle().apply {
                putString("studentId", studentId)
                putString("name", name)
                putString("email", email)
                putString("phone", phone)
                putString("nic", nic)
                putString("age", age)
                putString("gender", gender)
                putString("courseId", courseId)
                putString("password", password)
            }
        }
    }
}