package com.example.madcw

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.google.firebase.database.*

class StudentManageFragment : Fragment() {

    private lateinit var studentListLayout: LinearLayout
    private lateinit var headerTextView: TextView
    private lateinit var courseSpinner: Spinner
    private lateinit var database: DatabaseReference
    private lateinit var coursesDatabase: DatabaseReference
    private lateinit var courseList: MutableList<Course>
    private var selectedCourseId: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_student_manage, container, false)

        // Initialize views
        studentListLayout = view.findViewById(R.id.studentListLayout)
        headerTextView = view.findViewById(R.id.headerTextView)
        courseSpinner = view.findViewById(R.id.courseSpinner)

        // Initialize Firebase references
        database = FirebaseDatabase.getInstance().getReference("Student")
        coursesDatabase = FirebaseDatabase.getInstance().getReference("courses")

        // Load courses for spinner
        loadCourses()

        return view
    }

    private fun loadCourses() {
        courseList = mutableListOf()

        coursesDatabase.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                courseList.clear()

                // Add default "All Courses" option
                courseList.add(Course("", "All Courses"))

                for (courseSnapshot in snapshot.children) {
                    val courseId = courseSnapshot.key ?: continue
                    val courseName = courseSnapshot.child("name").getValue(String::class.java) ?: ""
                    courseList.add(Course(courseId, courseName))
                }

                // Create adapter
                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_spinner_item,
                    courseList.map { it.name }
                ).apply {
                    setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                }

                courseSpinner.adapter = adapter
                courseSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        selectedCourseId = courseList[position].id
                        loadStudentsForCourse()
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error loading courses", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun loadStudentsForCourse() {
        val query = if (selectedCourseId.isEmpty()) {
            // If "All Courses" is selected
            database.orderByChild("name")
        } else {
            // Filter by selected course
            database.orderByChild("courseId").equalTo(selectedCourseId)
        }

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Clear only student items (keep header)
                val childCount = studentListLayout.childCount
                for (i in childCount - 1 downTo 1) { // Start from last item, skip header (index 0)
                    studentListLayout.removeViewAt(i)
                }

                if (!snapshot.exists()) {
                    val emptyText = TextView(requireContext()).apply {
                        text = "No students found"
                        setTextColor(Color.GRAY)
                        textSize = 16f
                        gravity = Gravity.CENTER
                        setPadding(0, 32.dpToPx(context), 0, 0)
                    }
                    studentListLayout.addView(emptyText)
                    return
                }

                for (child in snapshot.children) {
                    val studentId = child.key ?: continue
                    val name = child.child("name").getValue(String::class.java) ?: ""
                    val email = child.child("email").getValue(String::class.java) ?: ""
                    val phone = child.child("phone").getValue(String::class.java) ?: ""
                    val nic = child.child("nic").getValue(String::class.java) ?: ""
                    val age = child.child("age").getValue(String::class.java) ?: ""
                    val gender = child.child("gender").getValue(String::class.java) ?: ""
                    val courseId = child.child("courseId").getValue(String::class.java) ?: ""
                    val password = child.child("password").getValue(String::class.java) ?: ""

                    // Get course name for display
                    val courseName = courseList.find { it.id == courseId }?.name ?: "Unknown Course"

                    val itemLayout = LinearLayout(requireContext()).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(24, 24, 24, 24)
                        setBackgroundColor(0xFFEEEEEE.toInt())

                        // Student ID
                        val idText = TextView(context).apply {
                            text = "ID: $studentId"
                            setTextColor(0xFF616161.toInt())
                            textSize = 14f
                            setTypeface(null, Typeface.BOLD)
                        }

                        // Name
                        val nameText = TextView(context).apply {
                            text = "Name: $name"
                            setTextColor(0xFF212121.toInt())
                            textSize = 16f
                        }

                        // Course
                        val courseText = TextView(context).apply {
                            text = "Course: $courseName"
                            setTextColor(0xFF757575.toInt())
                            textSize = 14f
                        }

                        // Button Container
                        val buttonContainer = LinearLayout(context).apply {
                            orientation = LinearLayout.HORIZONTAL
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ).apply {
                                topMargin = 12.dpToPx(context)
                            }
                        }

                        // Edit Button
                        val editButton = Button(context).apply {
                            text = "Edit"
                            setBackgroundColor(0xFF3F51B5.toInt())
                            setTextColor(Color.WHITE)
                            setOnClickListener {
                                val editFragment = EditStudentFragment.newInstance(
                                    studentId = studentId,
                                    name = name,
                                    email = email,
                                    phone = phone,
                                    nic = nic,
                                    age = age,
                                    gender = gender,
                                    courseId = courseId,
                                    password = password
                                )
                                parentFragmentManager.beginTransaction()
                                    .replace(R.id.fragmentContainer, editFragment)
                                    .addToBackStack(null)
                                    .commit()
                            }
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            )
                        }

                        // Delete Button
                        val deleteButton = Button(context).apply {
                            text = "Delete"
                            setBackgroundColor(0xFFF44336.toInt())
                            setTextColor(Color.WHITE)
                            setOnClickListener {
                                deleteStudent(studentId, courseId)
                            }
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ).apply {
                                marginStart = 8.dpToPx(context)
                            }
                        }

                        // Add views
                        addView(idText)
                        addView(nameText)
                        addView(courseText)
                        buttonContainer.addView(editButton)
                        buttonContainer.addView(deleteButton)
                        addView(buttonContainer)

                        // Add spacing between items
                        addView(View(context).apply {
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT, 24
                            )
                        })
                    }

                    studentListLayout.addView(itemLayout)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error loading students", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun deleteStudent(studentId: String, courseId: String) {
        AlertDialog.Builder(requireContext())
            .setTitle("Confirm Delete")
            .setMessage("Are you sure you want to delete this student?")
            .setPositiveButton("Delete") { _, _ ->
                // Remove from Students node
                database.child(studentId).removeValue()
                    .addOnSuccessListener {
                        // Remove from course's students list if course exists
                        if (courseId.isNotEmpty()) {
                            coursesDatabase.child("$courseId/students/$studentId").removeValue()
                        }
                        Toast.makeText(context, "Student deleted", Toast.LENGTH_SHORT).show()
                        loadStudentsForCourse() // Refresh the list
                    }
                    .addOnFailureListener {
                        Toast.makeText(context, "Failed to delete student", Toast.LENGTH_SHORT).show()
                    }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun Int.dpToPx(context: Context): Int {
        return (this * context.resources.displayMetrics.density).toInt()
    }

    data class Course(val id: String, val name: String)

    companion object {
        fun newInstance() = StudentManageFragment()
    }
}