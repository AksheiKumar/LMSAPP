package com.example.madcw

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.firebase.database.FirebaseDatabase
import java.util.*

class TeacherRegisterFragment : Fragment() {

    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etAge: EditText
    private lateinit var etNIC: EditText
    private lateinit var etQualificationInput: EditText
    private lateinit var tvQualifications: TextView
    private lateinit var btnAddQualification: Button
    private lateinit var btnRegister: Button
    private lateinit var rgGender: RadioGroup
    private lateinit var rbMale: RadioButton
    private lateinit var rbFemale: RadioButton

    private val qualificationList = mutableListOf<String>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_teacher_register, container, false)

        // Bind views
        etName = view.findViewById(R.id.etLecturerName)
        etEmail = view.findViewById(R.id.etEmail)
        etAge = view.findViewById(R.id.etAge)
        etNIC = view.findViewById(R.id.etNIC)
        etQualificationInput = view.findViewById(R.id.etQualificationInput)
        tvQualifications = view.findViewById(R.id.tvQualifications)
        btnAddQualification = view.findViewById(R.id.btnAddQualification)
        btnRegister = view.findViewById(R.id.btnRegisterLecturer)
        rgGender = view.findViewById(R.id.rgGender)
        rbMale = view.findViewById(R.id.rbMale)
        rbFemale = view.findViewById(R.id.rbFemale)

        btnAddQualification.setOnClickListener {
            val qualification = etQualificationInput.text.toString().trim()
            if (qualification.isNotEmpty()) {
                qualificationList.add(qualification)
                etQualificationInput.text.clear()
                updateQualificationDisplay()
            } else {
                Toast.makeText(requireContext(), "Enter a qualification", Toast.LENGTH_SHORT).show()
            }
        }

        btnRegister.setOnClickListener {
            registerLecturer()
        }

        return view
    }

    private fun updateQualificationDisplay() {
        tvQualifications.text = "Qualifications:\n• " + qualificationList.joinToString("\n• ")
    }

    private fun registerLecturer() {
        val name = etName.text.toString().trim()
        val age = etAge.text.toString().trim()
        val nic = etNIC.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val gender = getSelectedGender()

        if (name.isEmpty() || age.isEmpty() || nic.isEmpty() || email.isEmpty() || gender.isEmpty() || qualificationList.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val id = "LEC" + UUID.randomUUID().toString().substring(0, 6)
        val password = "Lec@${(1000..9999).random()}"

        val lecturerMap = HashMap<String, Any>()
        lecturerMap["id"] = id
        lecturerMap["name"] = name
        lecturerMap["age"] = age
        lecturerMap["gender"] = gender
        lecturerMap["nic"] = nic
        lecturerMap["email"] = email
        lecturerMap["password"] = password
        lecturerMap["qualifications"] = qualificationList

        FirebaseDatabase.getInstance().getReference("lecturers")
            .child(id)
            .setValue(lecturerMap)
            .addOnSuccessListener {
                Toast.makeText(
                    requireContext(),
                    "Lecturer Registered\nID: $id\nPassword: $password",
                    Toast.LENGTH_LONG
                ).show()
                clearForm()
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Registration failed: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun getSelectedGender(): String {
        return when (rgGender.checkedRadioButtonId) {
            R.id.rbMale -> "Male"
            R.id.rbFemale -> "Female"
            else -> ""
        }
    }

    private fun clearForm() {
        etName.text.clear()
        etEmail.text.clear()
        etAge.text.clear()
        etNIC.text.clear()
        etQualificationInput.text.clear()
        rgGender.clearCheck()
        qualificationList.clear()
        updateQualificationDisplay()
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            TeacherRegisterFragment().apply {
                arguments = Bundle().apply {
                    putString("param1", param1)
                    putString("param2", param2)
                }
            }
    }
}
