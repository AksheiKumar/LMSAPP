package com.example.madcw

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class AdminDashboardFragment : Fragment() {

    companion object {
        fun newInstance(uid: String): AdminDashboardFragment {
            val fragment = AdminDashboardFragment()
            val args = Bundle()
            args.putString("admin_id", uid)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_admin_dashboard, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val registerCard = view.findViewById<CardView>(R.id.card_register_admin)
        val assignLecturerCard = view.findViewById<CardView>(R.id.card_assign_lecturer)
        val qrscan_card = view.findViewById<CardView>(R.id.qrscan_card)
        val Course_Register = view.findViewById<CardView>(R.id.Course_Register)
        val Lecture_Reg = view.findViewById<CardView>(R.id.Lecture_Reg)
        val Student_Register = view.findViewById<CardView>(R.id.Student_Register)
        val Student_Management = view.findViewById<CardView>(R.id.Student_Management)
        val bottomNav = view.findViewById<BottomNavigationView>(R.id.bottom_nav_admin)

        registerCard.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, AdminRegisterFragment())
                .addToBackStack(null)
                .commit()
        }

        assignLecturerCard.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, AssignLecturerFragment())
                .addToBackStack(null)
                .commit()
        }

        qrscan_card.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, ScanAttendanceFragment())
                .addToBackStack(null)
                .commit()
        }
        Course_Register.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, CourseRegisterFragment())
                .addToBackStack(null)
                .commit()
        }
        Lecture_Reg.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, TeacherRegisterFragment())
                .addToBackStack(null)
                .commit()
        }
        Student_Register.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, StudentRegisterFragment())
                .addToBackStack(null)
                .commit()
        }

        Student_Management.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, StudentManageFragment())
                .addToBackStack(null)
                .commit()
        }
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true // Already on Home
                R.id.nav_settings -> {
                    Toast.makeText(requireContext(), "Settings clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_profile -> {
                    Toast.makeText(requireContext(), "Profile clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_logout -> {
                    parentFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, LoginFragment())
                        .commit()
                    true
                }
                else -> false
            }
        }
    }
}
