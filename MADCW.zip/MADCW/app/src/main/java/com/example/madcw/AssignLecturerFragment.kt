package com.example.madcw

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.HashMap

class AssignLecturerFragment : Fragment() {

    private lateinit var database: FirebaseDatabase
    private lateinit var courseList: MutableList<Course>
    private lateinit var lecturerList: MutableList<Lecturer>
    private lateinit var subjectList: MutableList<String>
    private lateinit var adapter: SubjectAssignmentAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_assign_lecturer, container, false)
        database = FirebaseDatabase.getInstance()

        val spinnerCourse = view.findViewById<Spinner>(R.id.spinnerCourse)
        val spinnerLecturer = view.findViewById<Spinner>(R.id.spinnerLecturer)
        val rvSubjects = view.findViewById<RecyclerView>(R.id.rvSubjects)
        val btnAssign = view.findViewById<Button>(R.id.btnAssignLecturer)
        val btnSave = view.findViewById<Button>(R.id.btnSaveAssignments)

        // Initialize lists
        courseList = mutableListOf()
        lecturerList = mutableListOf()
        subjectList = mutableListOf()

        // Setup adapter
        adapter = SubjectAssignmentAdapter(subjectList, lecturerList)
        rvSubjects.layoutManager = LinearLayoutManager(requireContext())
        rvSubjects.adapter = adapter

        // Load only courses initially
        loadCourses(spinnerCourse)

        // Course selection listener - loads everything else when course is selected
        spinnerCourse.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position >= 0) {
                    val selectedCourse = courseList[position]
                    // Load lecturers and subjects for this course
                    loadLecturers(spinnerLecturer)
                    loadSubjectsAndAssignments(selectedCourse.id)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        btnAssign.setOnClickListener {
            val selectedSubjectPosition = adapter.selectedSubjectPosition
            if (selectedSubjectPosition != -1) {
                if (spinnerLecturer.selectedItemPosition >= 0) {
                    val lecturerId = lecturerList[spinnerLecturer.selectedItemPosition].id
                    val subjectName = subjectList[selectedSubjectPosition]
                    adapter.setAssignment(subjectName, lecturerId)
                } else {
                    Toast.makeText(requireContext(), "Please select a lecturer", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "Please select a subject first", Toast.LENGTH_SHORT).show()
            }
        }

        // Save button click
        btnSave.setOnClickListener {
            if (spinnerCourse.selectedItemPosition >= 0) {
                saveAssignments(spinnerCourse.selectedItemPosition)
            } else {
                Toast.makeText(requireContext(), "Please select a course first", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    private fun loadCourses(spinner: Spinner) {
        database.getReference("courses").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                courseList.clear()
                for (courseSnapshot in snapshot.children) {
                    val course = Course().apply {
                        id = courseSnapshot.key ?: ""
                        name = courseSnapshot.child("name").getValue(String::class.java) ?: ""
                        code = courseSnapshot.child("code").getValue(String::class.java) ?: ""

                        val subjects = mutableListOf<String>()
                        for (subjectSnapshot in courseSnapshot.child("subjects").children) {
                            subjectSnapshot.getValue(String::class.java)?.let { subjects.add(it) }
                        }
                        this.subjects = subjects
                    }
                    courseList.add(course)
                }
                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_spinner_item,
                    courseList.map { "${it.name} (${it.code})" }
                )
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinner.adapter = adapter
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to load courses", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun loadLecturers(spinner: Spinner) {
        database.getReference("lecturers").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lecturerList.clear()
                for (lecturerSnapshot in snapshot.children) {
                    val lecturer = Lecturer().apply {
                        id = lecturerSnapshot.key ?: ""
                        name = lecturerSnapshot.child("name").getValue(String::class.java) ?: ""
                    }
                    lecturerList.add(lecturer)
                }
                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_spinner_item,
                    lecturerList.map { it.name }
                )
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinner.adapter = adapter
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to load lecturers", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun loadSubjectsAndAssignments(courseId: String) {
        subjectList.clear()
        adapter.clearAssignments()

        // Load subjects for selected course
        database.getReference("courses").child(courseId).child("subjects")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (subjectSnapshot in snapshot.children) {
                        val subject = subjectSnapshot.getValue(String::class.java)
                        subject?.let { subjectList.add(it) }
                    }
                    adapter.notifyDataSetChanged()

                    // Load existing assignments for this course
                    loadExistingAssignments(courseId)
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Failed to load subjects", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun loadExistingAssignments(courseId: String) {
        database.getReference("course_assignments").child(courseId).child("assignments")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (assignmentSnapshot in snapshot.children) {
                        val subject = assignmentSnapshot.child("subject").getValue(String::class.java)
                        val lecturerId = assignmentSnapshot.child("lecturerId").getValue(String::class.java)
                        if (subject != null && lecturerId != null) {
                            adapter.setAssignment(subject, lecturerId)
                        }
                    }
                    adapter.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    // No existing assignments is not an error
                }
            })
    }

    private fun saveAssignments(coursePosition: Int) {
        val courseId = courseList[coursePosition].id
        val assignmentsMap = HashMap<String, Any>()

        // Prepare assignments data
        val assignmentsList = adapter.getAssignmentsList()
        assignmentsList.forEachIndexed { index, assignment ->
            assignmentsMap["assignments/$index/subject"] = assignment.subject
            assignmentsMap["assignments/$index/lecturerId"] = assignment.lecturerId
        }

        // Save to database
        database.getReference("course_assignments").child(courseId)
            .updateChildren(assignmentsMap)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Assignments saved successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Failed to save assignments", Toast.LENGTH_SHORT).show()
            }
    }

    class Course {
        var id: String = ""
        var name: String = ""
        var code: String = ""
        var subjects: List<String> = emptyList()
    }

    class Lecturer {
        var id: String = ""
        var name: String = ""
    }

    class SubjectAssignment {
        var subject: String = ""
        var lecturerId: String = ""
    }

    class SubjectAssignmentAdapter(
        private val subjects: List<String>,
        private val lecturers: List<Lecturer>
    ) : RecyclerView.Adapter<SubjectAssignmentAdapter.SubjectViewHolder>() {

        internal var selectedSubjectPosition = -1
        private val assignments = mutableMapOf<String, String>() // subject to lecturerId

        inner class SubjectViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvSubject: TextView = view.findViewById(R.id.tvSubjectName)
            val tvLecturer: TextView = view.findViewById(R.id.tvAssignedLecturer)
            val container: View = view.findViewById(R.id.container)

            init {
                view.setOnClickListener {
                    selectedSubjectPosition = adapterPosition
                    notifyDataSetChanged()
                }
            }
        }

        fun clearAssignments() {
            assignments.clear()
            notifyDataSetChanged()
        }

        fun setAssignment(subjectName: String, lecturerId: String) {
            assignments[subjectName] = lecturerId
            notifyDataSetChanged()
        }

        fun getAssignmentsList(): List<SubjectAssignment> {
            return assignments.map { (subject, lecturerId) ->
                SubjectAssignment().apply {
                    this.subject = subject
                    this.lecturerId = lecturerId
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubjectViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_subject_assignment, parent, false)
            return SubjectViewHolder(view)
        }

        override fun onBindViewHolder(holder: SubjectViewHolder, position: Int) {
            val subject = subjects[position]
            holder.tvSubject.text = subject

            val lecturerId = assignments[subject]
            val lecturerName = lecturers.find { it.id == lecturerId }?.name ?: "Not assigned"
            holder.tvLecturer.text = lecturerName

            // Highlight selected item
            holder.container.setBackgroundColor(
                if (position == selectedSubjectPosition) {
                    ContextCompat.getColor(holder.itemView.context, R.color.selected_item)
                } else {
                    Color.TRANSPARENT
                }
            )
        }

        override fun getItemCount() = subjects.size
    }
}