package com.example.testable.fragment

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.testable.R
import com.example.testable.model.FileItem
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.*

class UploadFragment : Fragment() {

    private val FILE_REQUEST_CODE = 1001
    private var fileUri: Uri? = null
    private var isUploading = false

    private lateinit var titleEditText: EditText
    private lateinit var subjectEditText: EditText
    private lateinit var descriptionEditText: EditText
    private lateinit var batchEditText: EditText
    private lateinit var teacherIdEditText: EditText
    private lateinit var selectedFileTextView: TextView
    private lateinit var uploadButton: Button
    private lateinit var selectFileButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_upload, container, false)

        titleEditText = view.findViewById(R.id.titleEditText)
        subjectEditText = view.findViewById(R.id.subjectEditText)
        descriptionEditText = view.findViewById(R.id.descriptionEditText)
        batchEditText = view.findViewById(R.id.batchEditText)
        teacherIdEditText = view.findViewById(R.id.teacherIdEditText)
        selectedFileTextView = view.findViewById(R.id.selectedFileTextView)
        uploadButton = view.findViewById(R.id.uploadButton)
        selectFileButton = view.findViewById(R.id.selectFileButton)

        selectFileButton.setOnClickListener { openFileChooser() }

        uploadButton.setOnClickListener {
            if (fileUri != null) uploadFile()
            else Toast.makeText(requireContext(), "Please select a file", Toast.LENGTH_SHORT).show()
        }

        return view
    }

    private fun openFileChooser() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*"
        intent.putExtra(
            Intent.EXTRA_MIME_TYPES,
            arrayOf("application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        )
        startActivityForResult(Intent.createChooser(intent, "Select File"), FILE_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            fileUri = data.data
            selectedFileTextView.text = fileUri?.lastPathSegment ?: "File selected"
        }
    }

    private fun uploadFile() {
        if (isUploading) return

        val title = titleEditText.text.toString().trim()
        val subject = subjectEditText.text.toString().trim()
        val description = descriptionEditText.text.toString().trim()
        val batch = batchEditText.text.toString().trim()
        val teacherId = teacherIdEditText.text.toString().trim()

        if (title.isEmpty() || subject.isEmpty() || description.isEmpty() || batch.isEmpty() || teacherId.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val id = UUID.randomUUID().toString()
        val fileRef = FirebaseStorage.getInstance().reference.child("files/$id")

        isUploading = true

        fileUri?.let {
            fileRef.putFile(it)
                .addOnSuccessListener {
                    fileRef.downloadUrl.addOnSuccessListener { uri ->
                        val dateTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

                        val fileItem = FileItem(
                            id = id,
                            title = title,
                            subject = subject,
                            description = description,
                            batch = batch,
                            teacherId = teacherId,
                            fileUrl = uri.toString(),
                            uploadedAt = dateTime
                        )

                        FirebaseDatabase.getInstance().reference
                            .child("uploadedFiles")
                            .child(id) // Store by UUID
                            .setValue(fileItem)
                            .addOnSuccessListener {
                                Toast.makeText(requireContext(), "✅ Uploaded Successfully", Toast.LENGTH_SHORT).show()
                                clearFields()
                                isUploading = false
                            }
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Upload Failed", Toast.LENGTH_SHORT).show()
                    isUploading = false
                }
        }
    }

    private fun clearFields() {
        titleEditText.text.clear()
        subjectEditText.text.clear()
        descriptionEditText.text.clear()
        batchEditText.text.clear()
        teacherIdEditText.text.clear()
        selectedFileTextView.text = "No file selected"
        fileUri = null
    }
}
