package com.example.testable.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.testable.R

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        view.findViewById<Button>(R.id.btn_upload).setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, UploadFragment())
                .addToBackStack(null).commit()
        }

        view.findViewById<Button>(R.id.btn_view).setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, ViewFragment())
                .addToBackStack(null).commit()
        }

        view.findViewById<Button>(R.id.btn_view_sub).setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, ViewSubFragment())
                .addToBackStack(null).commit()
        }

        return view
    }
}