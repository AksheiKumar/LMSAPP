package com.example.testable.model

data class FileItem(
    val id: String = "",
    val title: String = "",
    val subject: String = "",
    val description: String = "",
    val batch: String = "",
    val teacherId: String = "",
    val fileUrl: String = "",
    val uploadedAt: String = ""
)