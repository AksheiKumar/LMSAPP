package com.example.testable.fragment

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.testable.R
import com.example.testable.model.FileItem
import com.google.firebase.database.FirebaseDatabase

class ViewFragment : Fragment() {

    private lateinit var batchSpinner: Spinner
    private lateinit var fileListLayout: LinearLayout
    private var allFiles: List<FileItem> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_view, container, false)

        batchSpinner = view.findViewById(R.id.categorySpinner) // Reuse existing ID
        fileListLayout = view.findViewById(R.id.categoryListLayout)

        batchSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, v: View?, position: Int, id: Long) {
                val selectedBatch = batchSpinner.selectedItem.toString()
                filterFilesByBatch(selectedBatch)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        loadAllFiles()
        return view
    }

    private fun loadAllFiles() {
        FirebaseDatabase.getInstance().reference.child("uploadedFiles")
            .get()
            .addOnSuccessListener { snapshot ->
                val batches = mutableSetOf<String>()
                val tempFiles = mutableListOf<FileItem>()

                snapshot.children.forEach { snap ->
                    val item = snap.getValue(FileItem::class.java)
                    item?.let {
                        tempFiles.add(it)
                        batches.add(it.batch)
                    }
                }

                allFiles = tempFiles
                val spinnerList = listOf("All") + batches.sorted()
                val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, spinnerList)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                batchSpinner.adapter = adapter
            }
    }

    private fun filterFilesByBatch(batch: String) {
        fileListLayout.removeAllViews()
        val filesToShow = if (batch == "All") allFiles else allFiles.filter { it.batch == batch }

        for (file in filesToShow) {
            val titleView = TextView(requireContext())
            titleView.text = "📄 ${file.title}"
            titleView.textSize = 18f
            titleView.setPadding(0, 16, 0, 4)
            fileListLayout.addView(titleView)

            val subjectView = TextView(requireContext())
            subjectView.text = "Subject: ${file.subject}"
            subjectView.setPadding(20, 0, 0, 4)
            fileListLayout.addView(subjectView)

            val batchView = TextView(requireContext())
            batchView.text = "Batch: ${file.batch}"
            batchView.setPadding(20, 0, 0, 4)
            fileListLayout.addView(batchView)

            val teacherView = TextView(requireContext())
            teacherView.text = "Teacher ID: ${file.teacherId}"
            teacherView.setPadding(20, 0, 0, 4)
            fileListLayout.addView(teacherView)

            val descView = TextView(requireContext())
            descView.text = "Description: ${file.description}"
            descView.setPadding(20, 0, 0, 4)
            fileListLayout.addView(descView)

            val dateView = TextView(requireContext())
            dateView.text = "Uploaded At: ${file.uploadedAt}"
            dateView.setPadding(20, 0, 0, 4)
            fileListLayout.addView(dateView)

            val openButton = Button(requireContext())
            openButton.text = "Open File"
            openButton.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(file.fileUrl))
                startActivity(intent)
            }
            openButton.setPadding(0, 0, 0, 16)
            fileListLayout.addView(openButton)
        }
    }
}
